import subprocess
import sys

subprocess.call(['./vm_translator', sys.argv[1]])
